#include <unistd.h>
#include <stdio.h>

int main(){
	printf("start this ok\n");		
	system("reboot");				   
	return 0;
}
